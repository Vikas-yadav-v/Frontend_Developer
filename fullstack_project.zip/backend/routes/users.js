const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const User = require('../models/User');

// get profile
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    res.json(user);
  } catch (err) { res.status(500).send('Server error'); }
});

// update profile
router.put('/me', auth, async (req, res) => {
  const { name, avatar } = req.body;
  try {
    const user = await User.findByIdAndUpdate(req.user.id, { $set: { name, avatar } }, { new: true }).select('-password');
    res.json(user);
  } catch (err) { res.status(500).send('Server error'); }
});

module.exports = router;
