import { Link } from 'react-router-dom'
export default function Layout({ children }){
  const logout = ()=>{ localStorage.removeItem('token'); window.location.href='/login' }
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="p-4 bg-white shadow-sm flex justify-between">
        <h1 className="font-bold">TopCredits</h1>
        <nav>
          <Link to='/dashboard' className="mr-4">Dashboard</Link>
          <Link to='/profile' className="mr-4">Profile</Link>
          <button onClick={logout}>Logout</button>
        </nav>
      </header>
      <main className="p-6">{children}</main>
    </div>
  )
}
