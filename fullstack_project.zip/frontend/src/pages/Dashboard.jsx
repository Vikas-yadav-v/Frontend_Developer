import { useEffect, useState } from 'react'
import { api } from '../api'

export default function Dashboard(){
  const [tasks, setTasks] = useState([])
  const [q, setQ] = useState('')
  const [title, setTitle] = useState('')

  const fetchTasks = async ()=>{
    try{ const res = await api.get('/tasks', { params: { q } }); setTasks(res.data) }
    catch(err){ console.error(err) }
  }

  useEffect(()=>{ fetchTasks() }, [])

  const create = async e=>{ e.preventDefault(); await api.post('/tasks', { title }); setTitle(''); fetchTasks() }

  const toggle = async (id, completed)=>{ await api.put(`/tasks/${id}`, { completed: !completed }); fetchTasks() }
  const remove = async id=>{ await api.delete(`/tasks/${id}`); fetchTasks() }

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Tasks</h2>
      <form onSubmit={create} className="mb-4 flex gap-2">
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="New task" className="p-2 border rounded flex-1" />
        <button className="bg-green-600 text-white px-4 py-2 rounded">Create</button>
      </form>
      <div className="mb-4">
        <input placeholder="Search" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>{ if(e.key==='Enter'){ fetchTasks() }}} className="p-2 border rounded w-full" />
      </div>
      <ul className="mt-4">
        {tasks.map(t=> (
          <li key={t._id} className="bg-white p-3 mb-2 rounded flex justify-between">
            <div>
              <input type='checkbox' checked={t.completed} onChange={()=>toggle(t._id, t.completed)} />
              <strong className="ml-2">{t.title}</strong>
              <p className="text-sm">{t.description}</p>
            </div>
            <button onClick={()=>remove(t._id)} className="text-red-600">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
