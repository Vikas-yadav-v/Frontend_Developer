import { useState } from 'react'
import { api } from '../api'
import { useNavigate } from 'react-router-dom'
export default function Login(){
  const [form, setForm] = useState({ email:'', password:'' })
  const nav = useNavigate()
  const submit = async e=>{
    e.preventDefault()
    try{ const res = await api.post('/auth/login', form); localStorage.setItem('token', res.data.token); nav('/dashboard') }
    catch(err){ alert(err.response?.data?.msg || 'Error') }
  }
  return (
    <form onSubmit={submit} className="max-w-md mx-auto bg-white p-6 rounded">
      <h2 className="text-xl font-semibold mb-4">Login</h2>
      <input required placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="w-full p-2 border mb-2" />
      <input required type='password' placeholder="Password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} className="w-full p-2 border mb-2" />
      <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded">Login</button>
    </form>
  )
}
