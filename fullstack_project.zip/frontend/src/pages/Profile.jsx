import { useEffect, useState } from 'react'
import { api } from '../api'
export default function Profile(){
  const [user, setUser] = useState(null)
  useEffect(()=>{ const load=async()=>{ try{ const res=await api.get('/users/me'); setUser(res.data) }catch(e){console.error(e)} }; load() }, [])
  if(!user) return <div>Loading...</div>
  return (
    <div className="max-w-md bg-white p-6 rounded">
      <h2 className="text-xl font-semibold">{user.name}</h2>
      <p>{user.email}</p>
    </div>
  )
}
