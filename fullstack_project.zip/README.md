# Fullstack Project (React + Tailwind frontend, Express + MongoDB backend)

## Quick start

### Backend
cd backend
cp .env.example .env
# edit .env (set MONGO_URI and JWT_SECRET)
npm install
npm run dev

### Frontend
cd frontend
npm install
npm run dev

Frontend expects backend at http://localhost:4000 by default.

